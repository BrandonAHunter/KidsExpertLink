# KidsExpertLink
Final Project for CSCE 546, App that links kids with ideas to professionals
